<?php
// set error reporting to ignore warnings and notice messages
error_reporting(E_ERROR | E_PARSE);

// initialize some variables
$data = array();
$key = null;
//

// open streams
$stdin = fopen('php://stdin','r');
$stdout = fopen('php://stdout','w');

// start with command stream reading
for(;;) {
  // read line from std in
  $line = fgets($stdin);   
  
  // explode it to parse the command string
  // [BEGIN|END] <COMMAND>
  // or <CONTENT>
  $cmd = explode(' ', trim($line), 2);
  
  // test command format
  if(count($cmd) == 2) {
    // if we found a start flag, set the key
    if($cmd[0] == 'START') {
      $key = trim($cmd[1]);
      continue;
    // if we found the end command, reset the keys and maybe abort this loop
    } else if($cmd[0] == 'END') {
      $data[$key] = trim($data[$key]);     
      $key = null;
      if($cmd[1] == 'TRANSACTION') {
        break;
      }
      continue;
    }
  }
  
  // add content to data array
  if(in_array($key, $data)) {
    $data[$key] = '\n' . $line;
  } else {
    $data[$key] = $line;
  }
}
// close stdin handle
fclose($stdin);

// test if the geshi script available
if(!file_exists($data['GESHI_SCRIPT'])) {
  // write error and close
  fwrite($stdout, 'File does not exists: "' . $data['GESHI_SCRIPT'] . '"');
  fclose($stdout);
  exit;
}

// include highlighter
include_once($data['GESHI_SCRIPT']);

// create object instance and pre-set some options
$geshi = new GeSHi();
$geshi->set_header_type(GESHI_HEADER_NONE);
$geshi->set_language_path($data['LANGUAGE_PATH']);
$geshi->set_language($data['LANGUAGE']);

// other option, handle it
if($data['RETURN_TYPE'] == 'LIST_OF_LANGUAGE') {
  // write all supported languages to console
  $arr = $geshi->get_supported_languages();
  fwrite($stdout, implode("\n", $arr));
  fclose($stdout);
  exit;
}

// activate line numbers if option is set
if($data['ENABLE_LINE_NUMBERS'] == 'True') {
  $geshi->enable_line_numbers(GESHI_NORMAL_LINE_NUMBERS);
}
$geshi->set_tab_width($data['TAB_WIDTH']);

// decode source
$source = base64_decode($data['SOURCE']);

// find out the marker length for extra highlighted lines
$markerLength = strlen($data['MARKER_EXTRA_HIGHLIGHTED_LINES']);
if($markerLength > 0) {
  // find extra highlighted lines
  $arrSource = explode("\n", $source);
  
  // array for line numbers
  $arrHighlighted = array();
  for($i=0; $i < count($arrSource); ++$i) {  
    // test if marker is found at start
    if(substr($arrSource[$i], 0, $markerLength) == $data['MARKER_EXTRA_HIGHLIGHTED_LINES']) {
      // push line numbers + 1
      array_push($arrHighlighted, $i+1);
      // remove marker from line
      $arrSource[$i] = substr($arrSource[$i], $markerLength);
    }
  }
  
  // build up the code
  $source = implode("\n", $arrSource);
  
  // set highlighted lines to geshi
  $geshi->highlight_lines_extra($arrHighlighted);
}

// set source
$geshi->set_source($source);

// parse it and write to std output stream
fwrite($stdout, '<code>' . $geshi->parse_code() . '</code>');
fclose($stdout);
?>